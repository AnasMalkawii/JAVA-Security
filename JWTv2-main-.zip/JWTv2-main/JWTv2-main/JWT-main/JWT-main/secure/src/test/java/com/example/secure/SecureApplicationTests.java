package com.example.secure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureApplicationTests {

	@Test
	void contextLoads() {
	}

}
